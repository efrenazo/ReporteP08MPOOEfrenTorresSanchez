public class Rectangulo extends Figura {
    protected double base;
    protected double altura;

    public Rectangulo(double base, double altura) {
        this("blanco", base, altura);
    }

    public Rectangulo(String color, double base, double altura) {
        this("rectangulo", color, base, altura);
    }

    // Constructor protegido: permite que Cuadrado cambie el nombre
    protected Rectangulo(String nombre, String color,
            double base, double altura) {
        super(nombre, color);
        this.base = base;
        this.altura = altura;
        System.out.println("[Rectangulo] " + base + " x " + altura);
    }

    @Override
    public double calcularArea() {
        return base * altura;
    }

    @Override
    public String toString() {
        return super.toString() + " | " + base + " x " + altura;
    }
}
