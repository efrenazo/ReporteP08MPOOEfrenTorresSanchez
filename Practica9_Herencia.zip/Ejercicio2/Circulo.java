public class Circulo extends Figura {
    private double radio;

    public Circulo(double radio) {
        this("blanco", radio);
    }

    public Circulo(String color, double radio) {
        super("circulo", color);
        this.radio = radio;
        System.out.println("[Circulo] radio " + radio);
    }

    @Override
    public double calcularArea() {
        return Math.PI * radio * radio;
    }

    @Override
    public String toString() {
        return super.toString() + " | r = " + radio;
    }
}
