public class Triangulo extends Figura {
    private double base;
    private double altura;

    public Triangulo(double base, double altura) {
        this("blanco", base, altura);
    }

    public Triangulo(String color, double base, double altura) {
        super("triangulo", color);
        this.base = base;
        this.altura = altura;
        System.out.println("[Triangulo] base " + base + ", altura " + altura);
    }

    @Override
    public double calcularArea() {
        return base * altura / 2;
    }

    @Override
    public String toString() {
        return super.toString() + " | b = " + base + ", h = " + altura;
    }
}
