// Un cuadrado es un rectangulo con base y altura iguales
public class Cuadrado extends Rectangulo {

    public Cuadrado(double lado) {
        this("blanco", lado);
    }

    public Cuadrado(String color, double lado) {
        super("cuadrado", color, lado, lado);
        System.out.println("[Cuadrado] lado " + lado);
    }

    // calcularArea() se hereda de Rectangulo: base * altura = lado * lado

    @Override
    public String toString() {
        return super.toString() + " (lado " + base + ")";
    }
}
