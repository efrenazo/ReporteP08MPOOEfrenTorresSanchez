public class Main {
    public static void main(String[] args) {
        Figura[] figuras = new Figura[5];
        figuras[0] = new Triangulo(6, 4);
        figuras[1] = new Cuadrado("verde", 5);
        figuras[2] = new Rectangulo("azul", 8, 3);
        figuras[3] = new Circulo("rojo", 2);
        figuras[4] = new Pentagono(4, 2.75);

        System.out.println("----- Figuras -----");
        double areaTotal = 0;
        for (Figura f : figuras) {
            System.out.println(f);
            areaTotal += f.calcularArea();
        }
        System.out.println("Area total: " + String.format("%.2f", areaTotal));
    }
}
