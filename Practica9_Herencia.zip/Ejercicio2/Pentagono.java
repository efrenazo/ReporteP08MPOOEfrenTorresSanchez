public class Pentagono extends Figura {
    private double lado;
    private double apotema;

    public Pentagono(double lado, double apotema) {
        this("blanco", lado, apotema);
    }

    public Pentagono(String color, double lado, double apotema) {
        super("pentagono", color);
        this.lado = lado;
        this.apotema = apotema;
        System.out.println("[Pentagono] lado " + lado + ", apotema " + apotema);
    }

    // Area = perimetro * apotema / 2
    @Override
    public double calcularArea() {
        double perimetro = 5 * lado;
        return perimetro * apotema / 2;
    }

    @Override
    public String toString() {
        return super.toString() + " | lado " + lado + ", apotema " + apotema;
    }
}
