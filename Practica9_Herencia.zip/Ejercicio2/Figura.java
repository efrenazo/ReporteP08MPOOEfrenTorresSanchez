public class Figura {
    protected String nombre;
    protected String color;

    public Figura() {
        this("sin-nombre");
    }

    public Figura(String nombre) {
        this(nombre, "blanco");
    }

    public Figura(String nombre, String color) {
        this.nombre = nombre;
        this.color = color;
        System.out.println("[Figura] creando " + nombre);
    }

    // Cada subclase sobrescribe este metodo con su formula
    public double calcularArea() {
        return 0.0;
    }

    @Override
    public String toString() {
        return nombre + " | color " + color
            + " | area " + String.format("%.2f", calcularArea());
    }
}
