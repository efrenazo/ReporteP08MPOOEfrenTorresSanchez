public class Figura {
    protected String nombre;
    protected String color;

    // Constructor vacio: todos los valores por defecto
    public Figura() {
        this("sin-nombre");
    }

    // Constructor con nombre: color por defecto
    public Figura(String nombre) {
        this(nombre, "blanco");
    }

    // Constructor completo: aqui terminan las llamadas con this
    public Figura(String nombre, String color) {
        this.nombre = nombre;
        this.color = color;
        System.out.println("[Figura] creando " + nombre);
    }

    public double calcularArea() {
        return 0.0;
    }

    @Override
    public String toString() {
        return nombre + " | color " + color;
    }
}
