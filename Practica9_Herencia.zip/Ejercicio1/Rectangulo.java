public class Rectangulo extends Figura {
    private double base;
    private double altura;

    // Constructor vacio: rectangulo de 1 x 1
    public Rectangulo() {
        this(1.0, 1.0);
    }

    // Constructor con medidas: color por defecto
    public Rectangulo(double base, double altura) {
        this("blanco", base, altura);
    }

    // Constructor completo: inicializa la parte del padre con super
    public Rectangulo(String color, double base, double altura) {
        super("rectangulo", color);
        this.base = base;
        this.altura = altura;
        System.out.println("[Rectangulo] listo de " + base + " x " + altura);
    }

    @Override
    public double calcularArea() {
        return base * altura;
    }

    @Override
    public String toString() {
        return super.toString() + " | " + base + " x " + altura
            + " | area " + String.format("%.2f", calcularArea());
    }
}
