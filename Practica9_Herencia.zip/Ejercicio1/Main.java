public class Main {
    public static void main(String[] args) {
        Figura generica = new Figura();
        Circulo c1 = new Circulo();
        Circulo c2 = new Circulo("rojo", 2.5);
        Rectangulo r1 = new Rectangulo(4, 3);
        Rectangulo r2 = new Rectangulo("azul", 6, 2);

        System.out.println(generica);
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(r1);
        System.out.println(r2);
    }
}
