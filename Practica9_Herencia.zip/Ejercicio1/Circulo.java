public class Circulo extends Figura {
    private double radio;

    // Constructor vacio: circulo de radio 1
    public Circulo() {
        this(1.0);
    }

    // Constructor con radio: color por defecto
    public Circulo(double radio) {
        this("blanco", radio);
    }

    // Constructor completo: inicializa la parte del padre con super
    public Circulo(String color, double radio) {
        super("circulo", color);
        this.radio = radio;
        System.out.println("[Circulo] listo con radio " + radio);
    }

    @Override
    public double calcularArea() {
        return Math.PI * radio * radio;
    }

    @Override
    public String toString() {
        return super.toString() + " | radio " + radio
            + " | area " + String.format("%.2f", calcularArea());
    }
}
