public class Villano extends Personaje {
    private int maldad;
    private String guarida;

    // Constructor con nombre: villano con valores por defecto
    public Villano(String nombre) {
        this(nombre, 5, 200, 50, "Cueva oscura");
    }

    // Constructor completo
    public Villano(String nombre, int nivel, int vida, int maldad, String guarida) {
        super(nombre, nivel, vida);
        this.maldad = maldad;
        this.guarida = guarida;
        System.out.println("[Villano] se esconde en " + guarida);
    }

    // Su maldad aumenta el danio: un 10 % de ella se suma al ataque
    @Override
    public int atacar() {
        return super.atacar() + maldad / 10;
    }

    @Override
    public String toString() {
        return "Villano: " + super.toString() + " | maldad " + maldad
            + " | guarida " + guarida;
    }
}
