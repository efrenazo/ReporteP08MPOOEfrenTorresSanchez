public class Guerrero extends Personaje {
    private int fuerza;
    private String arma;

    // Constructor con nombre: guerrero novato con espada
    public Guerrero(String nombre) {
        this(nombre, 1, 150, 10, "Espada");
    }

    // Constructor completo
    public Guerrero(String nombre, int nivel, int vida, int fuerza, String arma) {
        super(nombre, nivel, vida);
        this.fuerza = fuerza;
        this.arma = arma;
        System.out.println("[Guerrero] empuna " + arma);
    }

    // El guerrero suma su fuerza al danio base
    @Override
    public int atacar() {
        return super.atacar() + fuerza;
    }

    @Override
    public String toString() {
        return "Guerrero: " + super.toString() + " | fuerza " + fuerza
            + " | arma " + arma;
    }
}
