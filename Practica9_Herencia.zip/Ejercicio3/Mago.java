public class Mago extends Personaje {
    private int mana;
    private String hechizo;

    // Constructor con nombre: mago novato
    public Mago(String nombre) {
        this(nombre, 1, 80, 100, "Chispa");
    }

    // Constructor completo
    public Mago(String nombre, int nivel, int vida, int mana, String hechizo) {
        super(nombre, nivel, vida);
        this.mana = mana;
        this.hechizo = hechizo;
        System.out.println("[Mago] domina el hechizo " + hechizo);
    }

    // El mago gasta mana para hacer mas danio
    @Override
    public int atacar() {
        if (mana >= 20) {
            mana = mana - 20;
            return super.atacar() + 25;
        }
        return super.atacar();
    }

    @Override
    public String toString() {
        return "Mago: " + super.toString() + " | mana " + mana
            + " | hechizo " + hechizo;
    }
}
