public class Aldeano extends Personaje {
    private String oficio;

    // Constructor vacio: aldeano sin nombre ni oficio
    public Aldeano() {
        this("Aldeano", "sin oficio");
    }

    // Constructor con nombre y oficio: usa el constructor de Personaje con nombre
    public Aldeano(String nombre, String oficio) {
        super(nombre);
        this.oficio = oficio;
        System.out.println("[Aldeano] trabaja de " + oficio);
    }

    // Un aldeano no pelea
    @Override
    public int atacar() {
        return 0;
    }

    public String ofrecerAyuda() {
        return nombre + " (" + oficio + ") ofrece ayuda a los heroes.";
    }

    @Override
    public String toString() {
        return "Aldeano: " + super.toString() + " | oficio " + oficio;
    }
}
