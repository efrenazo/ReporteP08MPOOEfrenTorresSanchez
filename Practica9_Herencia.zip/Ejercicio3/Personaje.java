public class Personaje {
    protected String nombre;
    protected int nivel;
    protected int vida;

    // Constructor vacio: personaje sin nombre
    public Personaje() {
        this("sin-nombre");
    }

    // Constructor con nombre: nivel 1 y 100 de vida
    public Personaje(String nombre) {
        this(nombre, 1, 100);
    }

    // Constructor completo: aqui terminan las llamadas con this
    public Personaje(String nombre, int nivel, int vida) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.vida = vida;
        System.out.println("[Personaje] creando " + nombre);
    }

    // Danio base de cualquier personaje
    public int atacar() {
        return nivel * 2;
    }

    public void recibirDanio(int danio) {
        vida = vida - danio;
        if (vida < 0) {
            vida = 0;
        }
    }

    public boolean estaVivo() {
        return vida > 0;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre + " | nivel " + nivel + " | vida " + vida;
    }
}
