public class Main {
    public static void main(String[] args) {
        Personaje[] personajes = new Personaje[5];
        personajes[0] = new Mago("Merlin", 3, 90, 100, "Bola de fuego");
        personajes[1] = new Guerrero("Arturo");
        personajes[2] = new Villano("Morgana");
        personajes[3] = new Aldeano("Tomas", "herrero");
        personajes[4] = new Aldeano();

        System.out.println("----- Personajes -----");
        for (Personaje p : personajes) {
            System.out.println(p);
            if (p instanceof Aldeano) {
                Aldeano a = (Aldeano) p;
                System.out.println("  -> " + a.ofrecerAyuda());
            }
        }

        System.out.println("----- Batalla -----");
        Personaje villano = personajes[2];
        for (int i = 0; i < 4; i++) {
            Personaje heroe = personajes[i];
            if (heroe == villano) {
                continue;
            }
            int danio = heroe.atacar();
            villano.recibirDanio(danio);
            System.out.println(heroe.getNombre() + " ataca a "
                + villano.getNombre() + " y le hace " + danio + " de danio");
        }
        int danioVillano = villano.atacar();
        personajes[1].recibirDanio(danioVillano);
        System.out.println(villano.getNombre() + " contraataca a "
            + personajes[1].getNombre() + " y le hace " + danioVillano + " de danio");

        System.out.println("----- Estado final -----");
        System.out.println(villano);
        System.out.println(personajes[1]);
    }
}
